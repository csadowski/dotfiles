.. :changelog:

Changelog
---------

0.6.0 (2013-05-14)
++++++++++++++++++

* much faster parser with builtin part caching
* a test suite, thanks @tkf

0.5 versions (2012)
+++++++++++++++++++

* Initial development
