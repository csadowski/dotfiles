﻿using OmniSharp.Common;

namespace OmniSharp.LookupAllTypes
{
    public class LookupAllTypesRequest : Request
    {
    }
}