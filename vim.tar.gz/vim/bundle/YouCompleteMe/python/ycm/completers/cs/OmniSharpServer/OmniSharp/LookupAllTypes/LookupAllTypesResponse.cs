﻿namespace OmniSharp.LookupAllTypes
{
    public class LookupAllTypesResponse
    {
        public string Types;
        public string Interfaces;
    }
}
