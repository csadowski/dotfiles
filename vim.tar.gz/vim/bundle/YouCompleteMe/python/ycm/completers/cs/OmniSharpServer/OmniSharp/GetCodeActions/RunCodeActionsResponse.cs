﻿namespace OmniSharp.GetCodeActions
{
    public class RunCodeActionsResponse
    {
        public string Text { get; set; }
    }
}